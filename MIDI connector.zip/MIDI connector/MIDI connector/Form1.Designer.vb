﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ComboBoxInputDevice = New System.Windows.Forms.ComboBox()
        Me.ComboBoxOutputDevice = New System.Windows.Forms.ComboBox()
        Me.ButtonConnect = New System.Windows.Forms.Button()
        Me.LabelMidiInputDevice = New System.Windows.Forms.Label()
        Me.LabelMidiOutputDevice = New System.Windows.Forms.Label()
        Me.FlowAnimation = New System.Windows.Forms.PictureBox()
        CType(Me.FlowAnimation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ComboBoxInputDevice
        '
        Me.ComboBoxInputDevice.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxInputDevice.FormattingEnabled = True
        Me.ComboBoxInputDevice.Location = New System.Drawing.Point(23, 40)
        Me.ComboBoxInputDevice.Name = "ComboBoxInputDevice"
        Me.ComboBoxInputDevice.Size = New System.Drawing.Size(220, 26)
        Me.ComboBoxInputDevice.TabIndex = 0
        '
        'ComboBoxOutputDevice
        '
        Me.ComboBoxOutputDevice.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxOutputDevice.FormattingEnabled = True
        Me.ComboBoxOutputDevice.Location = New System.Drawing.Point(400, 40)
        Me.ComboBoxOutputDevice.Name = "ComboBoxOutputDevice"
        Me.ComboBoxOutputDevice.Size = New System.Drawing.Size(220, 26)
        Me.ComboBoxOutputDevice.TabIndex = 1
        '
        'ButtonConnect
        '
        Me.ButtonConnect.Enabled = False
        Me.ButtonConnect.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonConnect.Location = New System.Drawing.Point(256, 39)
        Me.ButtonConnect.Name = "ButtonConnect"
        Me.ButtonConnect.Size = New System.Drawing.Size(130, 26)
        Me.ButtonConnect.TabIndex = 2
        Me.ButtonConnect.Text = "Connect"
        Me.ButtonConnect.UseVisualStyleBackColor = True
        '
        'LabelMidiInputDevice
        '
        Me.LabelMidiInputDevice.AutoSize = True
        Me.LabelMidiInputDevice.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMidiInputDevice.Location = New System.Drawing.Point(41, 10)
        Me.LabelMidiInputDevice.Name = "LabelMidiInputDevice"
        Me.LabelMidiInputDevice.Size = New System.Drawing.Size(178, 18)
        Me.LabelMidiInputDevice.TabIndex = 3
        Me.LabelMidiInputDevice.Text = "MIDI input device"
        '
        'LabelMidiOutputDevice
        '
        Me.LabelMidiOutputDevice.AutoSize = True
        Me.LabelMidiOutputDevice.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMidiOutputDevice.Location = New System.Drawing.Point(414, 10)
        Me.LabelMidiOutputDevice.Name = "LabelMidiOutputDevice"
        Me.LabelMidiOutputDevice.Size = New System.Drawing.Size(188, 18)
        Me.LabelMidiOutputDevice.TabIndex = 4
        Me.LabelMidiOutputDevice.Text = "MIDI output device"
        '
        'FlowAnimation
        '
        Me.FlowAnimation.Image = Global.MIDI_connector.My.Resources.Resources.indeterminate_progress_bar
        Me.FlowAnimation.Location = New System.Drawing.Point(256, 18)
        Me.FlowAnimation.Name = "FlowAnimation"
        Me.FlowAnimation.Size = New System.Drawing.Size(130, 4)
        Me.FlowAnimation.TabIndex = 5
        Me.FlowAnimation.TabStop = False
        Me.FlowAnimation.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(636, 86)
        Me.Controls.Add(Me.FlowAnimation)
        Me.Controls.Add(Me.LabelMidiOutputDevice)
        Me.Controls.Add(Me.LabelMidiInputDevice)
        Me.Controls.Add(Me.ButtonConnect)
        Me.Controls.Add(Me.ComboBoxOutputDevice)
        Me.Controls.Add(Me.ComboBoxInputDevice)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "MIDI connector"
        CType(Me.FlowAnimation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ComboBoxInputDevice As ComboBox
    Friend WithEvents ComboBoxOutputDevice As ComboBox
    Friend WithEvents ButtonConnect As Button
    Friend WithEvents LabelMidiInputDevice As Label
    Friend WithEvents LabelMidiOutputDevice As Label
    Friend WithEvents FlowAnimation As PictureBox
End Class
