﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form1))
        ComboBoxInputDevice = New ComboBox()
        ComboBoxOutputDevice = New ComboBox()
        ButtonConnect = New Button()
        LabelMidiInputDevice = New Label()
        LabelMidiOutputDevice = New Label()
        Label3 = New Label()
        SuspendLayout()
        ' 
        ' ComboBoxInputDevice
        ' 
        ComboBoxInputDevice.Font = New Font("Courier New", 9.75F, FontStyle.Regular, GraphicsUnit.Point)
        ComboBoxInputDevice.FormattingEnabled = True
        ComboBoxInputDevice.ItemHeight = 16
        ComboBoxInputDevice.Location = New Point(21, 40)
        ComboBoxInputDevice.Name = "ComboBoxInputDevice"
        ComboBoxInputDevice.Size = New Size(222, 24)
        ComboBoxInputDevice.TabIndex = 0
        ComboBoxInputDevice.Text = "Select device"
        ' 
        ' ComboBoxOutputDevice
        ' 
        ComboBoxOutputDevice.Font = New Font("Courier New", 9.75F, FontStyle.Regular, GraphicsUnit.Point)
        ComboBoxOutputDevice.FormattingEnabled = True
        ComboBoxOutputDevice.Location = New Point(418, 40)
        ComboBoxOutputDevice.Name = "ComboBoxOutputDevice"
        ComboBoxOutputDevice.Size = New Size(220, 24)
        ComboBoxOutputDevice.TabIndex = 1
        ComboBoxOutputDevice.Text = "Select device"
        ' 
        ' ButtonConnect
        ' 
        ButtonConnect.Font = New Font("Courier New", 9.75F, FontStyle.Regular, GraphicsUnit.Point)
        ButtonConnect.Location = New Point(265, 39)
        ButtonConnect.Name = "ButtonConnect"
        ButtonConnect.Size = New Size(134, 25)
        ButtonConnect.TabIndex = 2
        ButtonConnect.Text = "Connect"
        ButtonConnect.UseVisualStyleBackColor = True
        ' 
        ' LabelMidiInputDevice
        ' 
        LabelMidiInputDevice.AutoSize = True
        LabelMidiInputDevice.Font = New Font("Courier New", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        LabelMidiInputDevice.Location = New Point(21, 9)
        LabelMidiInputDevice.Name = "LabelMidiInputDevice"
        LabelMidiInputDevice.Size = New Size(161, 17)
        LabelMidiInputDevice.TabIndex = 3
        LabelMidiInputDevice.Text = "MIDI input device"
        ' 
        ' LabelMidiOutputDevice
        ' 
        LabelMidiOutputDevice.AutoSize = True
        LabelMidiOutputDevice.Font = New Font("Courier New", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        LabelMidiOutputDevice.Location = New Point(468, 9)
        LabelMidiOutputDevice.Name = "LabelMidiOutputDevice"
        LabelMidiOutputDevice.Size = New Size(170, 17)
        LabelMidiOutputDevice.TabIndex = 4
        LabelMidiOutputDevice.Text = "MIDI output device"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Calibri", 14.25F, FontStyle.Regular, GraphicsUnit.Point)
        Label3.Location = New Point(188, 6)
        Label3.Name = "Label3"
        Label3.Size = New Size(274, 23)
        Label3.TabIndex = 7
        Label3.Text = "→→   →→   →→   →→   →→   →→"
        Label3.Visible = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(666, 84)
        Controls.Add(Label3)
        Controls.Add(LabelMidiOutputDevice)
        Controls.Add(LabelMidiInputDevice)
        Controls.Add(ButtonConnect)
        Controls.Add(ComboBoxOutputDevice)
        Controls.Add(ComboBoxInputDevice)
        Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        FormBorderStyle = FormBorderStyle.FixedSingle
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form1"
        Text = "MIDI connector"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents ComboBoxInputDevice As ComboBox
    Friend WithEvents ComboBoxOutputDevice As ComboBox
    Friend WithEvents ButtonConnect As Button
    Friend WithEvents LabelMidiInputDevice As Label
    Friend WithEvents LabelMidiOutputDevice As Label
    Friend WithEvents Label3 As Label
End Class
